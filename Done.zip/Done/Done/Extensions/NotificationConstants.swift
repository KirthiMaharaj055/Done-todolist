//
//  NotificationConstants.swift
//  Goback
//
//  Created by Zeqiel Golomb on 11/3/20.
//  Copyright © 2020 Zeqe Golomb. All rights reserved.
//

import Foundation

let COLOR_NOTIFICATION = NSNotification.Name("color")
let COLORFORFIELD_NOTIFICATION = NSNotification.Name("color")
let MONTHCHANGE_NOTIFICATION = NSNotification.Name("month")
let YEARCHANGE_NOTIFICATION = NSNotification.Name("year")
let DAYCHANGE_NOTIFICATION = NSNotification.Name("day")
let TIME_NOTIFICATION = NSNotification.Name("time")
