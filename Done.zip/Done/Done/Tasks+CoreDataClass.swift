//
//  Tasks+CoreDataClass.swift
//  
//
//  Created by Kirthi Maharaj on 2021/10/15.
//
//

import Foundation
import CoreData

@objc(Tasks)
public class Tasks: NSManagedObject {
    
}
