//
//  Subtask+CoreDataClass.swift
//  Done
//
//  Created by Kirthi Maharaj on 2021/10/15.
//
//

import Foundation
import CoreData

@objc(Subtask)
public class Subtask: NSManagedObject {

}
